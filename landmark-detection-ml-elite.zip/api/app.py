from fastapi import FastAPI, UploadFile, File
import tensorflow as tf
import numpy as np
import cv2

app = FastAPI(title="Landmark Detection API")

model = tf.keras.models.load_model("models/landmark_model.h5")

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    img_bytes = await file.read()
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    img = cv2.resize(img, (224, 224))/255.0
    img = np.expand_dims(img, 0)
    pred = np.argmax(model.predict(img), axis=1)[0]
    return {"prediction": int(pred)}
