# Landmark Detection – Production Grade ML Project

A production-quality deep learning system for landmark image classification with:
- Transfer learning (MobileNetV2)
- Experiment tracking
- Reproducible training config
- FastAPI REST inference service
- Docker deployment
- ONNX export for cross-platform inference
- Evaluation visualizations

## Quick Start
```
pip install -r requirements.txt
python scripts/train.py
python scripts/evaluate.py
```

## Serve API
```
uvicorn api.app:app --reload
```

## Docker
```
docker build -t landmark-api .
docker run -p 8000:8000 landmark-api
```

