def test_imports():
    import tensorflow
    assert True
