import tensorflow as tf
import tf2onnx

model = tf.keras.models.load_model("models/landmark_model.h5")
spec = (tf.TensorSpec((None,224,224,3), tf.float32, name="input"),)
onnx_model, _ = tf2onnx.convert.from_keras(model, input_signature=spec, opset=13)
with open("models/landmark_model.onnx","wb") as f:
    f.write(onnx_model.SerializeToString())
